/*
 * JSONString.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#include"JSONLib.h"

JSONString::JSONString()
{
    type = T_STRING;
    _value = "";
}
JSONString::~JSONString(){}

void JSONString::value(string val)
{
    _value = val;
}

string JSONString::value()
{
    return _value;
}

string JSONString::toJSON()
{
    //TODO: Formatear el texto para los caracteres especiales.
    std::ostringstream out;
    out << "\"" << _name << "\":";
    out << toJSONValue();
    return out.str();
}

string JSONString::toJSONValue()
{
    std::ostringstream out;
    out << "\"" << _value << "\"";
    return out.str();
}
