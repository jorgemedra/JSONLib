/*
 * JSONArray.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#include"JSONLib.h"

JSONArray::JSONArray()
{
	type = T_ARRAY;
	_count = 0;
}
JSONArray::~JSONArray()
{
	std::vector<JSONValue*>::iterator it;
	_count=0;
	for (it=_value.begin(); it != _value.end(); ++it)
		delete *it;
	_value.clear();

}

void JSONArray::insert(JSONValue* val)
{
	_value.push_back(val);
	_count++;
}

JSONValue* JSONArray::operator[] (int index)
{
	if(index < 0 || index >= _count)
		return NULL;
	return _value[index];
}

int JSONArray::getCount()
{
	return _count;
}

string JSONArray::toJSON()
{
	std::ostringstream out;
	if(strcmp(_name.c_str(),"") != 0)
		out << "\"" << _name << "\":";
	out << toJSONValue();
	return out.str();
}

string JSONArray::toJSONValue()
{
	std::vector<JSONValue*>::iterator it;
	std::ostringstream out;
	bool bComa = false;

	out << "[";

	for (it = _value.begin(); it != _value.end(); ++it)
	{
		if(bComa)
			out << ",";
		else
			bComa = true;

		out << (*it)->toJSONValue();
	}

	out << "]";

	return out.str();
}
