/*
 * JSONUnicode.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#include"JSONLib.h"

JSONUnicode::JSONUnicode()
{
    
}

JSONUnicode::~JSONUnicode()
{
    
}

/**
 * Method: encode
 * 
 * Method to encode a sting to string with UNICODE charateres using tow-characters scape.
 */ 
string JSONUnicode::encodeString(string str)
{
	int offset = 0;
	int size = 0;
	std::ostringstream out;

	size = str.size();
	if(size <= 0)
		return "";

	while( offset < size )
	{
		char c = str[offset];
		offset++;

		switch (c)
		{
			case '\u005c': // '\'
				out << '\u005c' << '\u005c';
				break;
			case '\u0022': // '"'
				out << '\u005c' << '\u0022';
				break;
			case '\u002f': // '/'
				out << '\u005c' << '\u002f';
				break;
			case '\u0008': // '\b'
				out << '\u005c' << 'b';
				break;
			case '\u000a': // '\n'
				out << '\u005c' << 'n';
				break;
			case '\u000d': // '\r'
				out << '\u005c' << 'r';
				break;
			case '\u0009': // '\t'
				out << '\u005c' << 't';
				break;
			case '\u000c': // '\f'
				out << '\u005c' << 'f';
				break;
			default:
				out << c;
				break;
		}//switch

	}//while

    return out.str();
}

string JSONUnicode::decodeString(string ucdStr)
{
	int offset = 0;
	std::ostringstream out;
	std::ostringstream outInt;

    if(ucdStr.size() <=0)
        return "";
    
	int size = ucdStr.size();


	while( offset < size )
	{
		string vUnicode;
		char c = ucdStr[offset];
		offset++;
		if(c == '\u005c')
		{
			c = ucdStr[offset];
			offset++;
			switch (c)
			{
				case 'b':
					c = '\u0008';
					break;
				case 'f':
					c = '\u000c';
					break;
				case 'n':
					c = '\u000a';
					break;
				case 'r':
					c = '\u000d';
					break;
				case 't':
					c = '\u0009';
					break;
				case 'u':	// DIGITOS '\u0023';
					//char cc = ucdStr[offset];
					for(int i=0; i<4;i++)
					{
						outInt << ucdStr[offset];
						offset++;

					}

					string vl = outInt.str();
					unsigned int v = std::strtoul(outInt.str().c_str(),NULL,16);
					c = (char)v;
					break;

			}//switch
		}

		out << c;

	}//while

	return out.str();
}

