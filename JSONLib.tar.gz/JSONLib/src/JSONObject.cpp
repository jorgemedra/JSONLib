/*
 * JSONObject.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#include"JSONLib.h"

JSONObject::JSONObject() {
	type = T_OBJECT;
	_count = 0;
}

JSONObject::~JSONObject() {
	std::vector<JSONValue*>::iterator it;
	for (it=_value.begin(); it != _value.end(); ++it)
	{
		if(*it != NULL)
			delete *it;
	}

	_value.clear();
	_valuem.clear();
	_count=0;
}

void JSONObject::insert(JSONValue* val)
{
	if(val!= NULL)
	{
		_value.push_back(val);
		_valuem[val->name()] = val;
		_count++;
	}
}

JSONValue* JSONObject::operator[](int index)
{
	if(index < 0 || index >= _count)
		return NULL;

	return _value[index];
}

JSONValue* JSONObject::operator[](string key)
{
	return _valuem[key];
}

int JSONObject::getCount()
{
	return _count;
}

string JSONObject::toJSON()
{
	std::ostringstream out;
	if(strcmp(_name.c_str(),"") != 0)
		out << "\"" << _name << "\":";
	out << toJSONValue();
	return out.str();
}

string JSONObject::toJSONValue()
{
	std::ostringstream out;
	std::vector<JSONValue*>::iterator it;
	bool bComma = false;

	if(_count <= 0) return "null";

	out << "{";
	for (it=_value.begin(); it != _value.end(); ++it)
	{
		if(bComma)
			out << ",";
		else
			bComma  = true;
		out << (*it)->toJSON();
	}
	out << "}";

	return out.str();
}
