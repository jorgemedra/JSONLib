/*
 * JSONLib.h
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#ifndef JSONLIB_H_
#define JSONLIB_H_

#include<cstdlib>
#include<iostream>
#include<cstring>
#include<iostream>
#include<sstream>
#include<iomanip>
#include<string>
#include<cstdio>
#include<vector>
#include<map>


using namespace std;

enum JSONValueType
{
    T_UNKOWN =0,
    T_NULL,
    T_STRING,
    T_NUMBER,
    T_BOOL,
    T_OBJECT,
    T_ARRAY
};


class JSONValue
{
protected:
    string _name;
    JSONValueType type;
public:
    JSONValue();
    virtual ~JSONValue();

    void name(string name);
    string name();

    virtual string toJSON();
    virtual string toJSONValue();
    JSONValueType getType();

};


class JSONNull:public JSONValue
{
private:

public:
    JSONNull();
    virtual ~JSONNull();
    string toJSON();
    string toJSONValue();
};


class JSONNumber:public JSONValue
{
private:
    double _value;
    bool isDouble;
public:
    JSONNumber();
    virtual ~JSONNumber();
    void value(long val);
    void value(double val);
    long intValue();
    double dlbValue();
    bool isInteger();
    string toJSON();
    string toJSONValue();
};





class JSONBool:public JSONValue
{
private:
    bool _value;
public:
    JSONBool();
    virtual ~JSONBool();
    void value(bool val);
    bool value();
    string toJSON();
    string toJSONValue();
};

class JSONString:public JSONValue
{
private:
    string _value;
public:
    JSONString();
    virtual ~JSONString();
    void value(string val);
    string value();
    string toJSON();
    string toJSONValue();
};

class JSONObject: public JSONValue
{
private:
    int _count;
    vector<JSONValue*> _value;
    map<string, JSONValue*> _valuem;

public:
    JSONObject();
    virtual ~JSONObject();

    void insert(JSONValue* val);
    JSONValue* operator [] (int);
    JSONValue* operator [] (string key);
    int getCount();

    string toJSON();
    string toJSONValue();
};

class JSONArray:public JSONValue
{
private:
    vector<JSONValue*> _value;
    int _count;

public:
    JSONArray();
    ~JSONArray();

    void insert(JSONValue* val);
    JSONValue* operator[] (int index);
    int getCount();

    string toJSON();
    string toJSONValue();
};

class JSONFactory {

	JSONObject* parseJObject(string jsonmsg, int* offset, int* errCode, string* errDesc);
	JSONArray* parseJArray(string jsonmsg, int* offset, int* errCode, string* errDesc);

	string parseKey(string jsonmsg, int* offset, int* errCode, string* errDesc);
	JSONValue* parseValue(string jsonmsg, int* offset, int* errCode, string* errDesc);

	void parseNull(string jsonmsg, int* offset, int* errCode, string* errDesc);
	bool parseBool(string jsonmsg, int* offset, int* errCode, string* errDesc);
	double parseNumber(string jsonmsg, bool* isInteger, int* offset, int* errCode, string* errDesc);
	string parseString(string jsonmsg, int* offset, int* errCode, string* errDesc);


public:
	JSONFactory();
	virtual ~JSONFactory();

	JSONValue* parseJSON(string, int* errCode, string* errDesc);

};

class JSONUnicode
{

public:
    JSONUnicode();
    ~JSONUnicode();

    string encodeString(string);
    string decodeString(string);
};

#define ERR_C_OK 				0
#define ERR_D_OK 				"OK\0"
#define ERR_C_EXP_OBJARR 		1
#define ERR_D_EXP_OBJARR 		"Invalid message format, it expected an object '{}' or array '[]'\0"
#define ERR_C_EXP_DLBQUOTE 		2
#define ERR_D_EXP_DLBQUOTE 		"Invalid message format, it expected a double quote '\"'\0"
#define ERR_C_EXP_NULL	 		3
#define ERR_D_EXP_NULL 			"Invalid message format, it expected a null value 'null'\0"
#define ERR_C_EXP_BOOL	 		4
#define ERR_D_EXP_BOOL 			"Invalid message format, it expected a boolean value 'true' or 'false'\0"
#define ERR_C_EXP_NUMBER 		5
#define ERR_D_EXP_NUMBER		"Invalid message format, it expected a number value (log|value)\0"
#define ERR_C_EXP_ARR 			6
#define ERR_D_EXP_ARR			"Invalid message format, it expected an array '[]'\0"

#endif /* JSONLIB_H_ */
