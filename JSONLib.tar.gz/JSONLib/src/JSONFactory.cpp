/*
 * JSONFactory.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#include"JSONLib.h"
#include <cstdlib>

JSONFactory::JSONFactory() {
}

JSONFactory::~JSONFactory() {
}


JSONValue* JSONFactory::parseJSON(string jsonmsg, int* errCode, string* errDesc)
{
	int offset;
	JSONArray* jArr;
	JSONObject* jObj;
	JSONNull* jNull;
	std::ostringstream outErr;

	*errCode = ERR_C_OK;
	errDesc->operator = (ERR_D_OK);

	offset = 0; //look for an Object from begin
	jObj = parseJObject(jsonmsg,&offset,errCode,errDesc);

	if(*errCode == ERR_C_OK)
		return jObj;
	else
		delete jObj; //Free the memory

	if(*errCode == ERR_C_EXP_OBJARR)
	{
		offset = 0; //look for an Array from begin
		jArr = parseJArray(jsonmsg,&offset,errCode,errDesc);

		if(*errCode == ERR_C_OK)
			return jArr;
		else
			delete jArr;
	}

	jNull = new JSONNull();
	outErr << "Error at position[" << offset <<"]: "<< *errDesc;
	errDesc->operator = (outErr.str());

	return jNull; //Or Object
}

JSONObject* JSONFactory::parseJObject(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	JSONObject* obj = new JSONObject();
	char c = '\0';
	int size = jsonmsg.size();
	string name;
	bool bStarted = true;

	c = '\0';
	//check Value
	while(*offset < size)
	{
		c = jsonmsg[*offset];
		if((bStarted && c == '{') || (!bStarted && c == ',')) //Get Name String
		{
			*offset+=1;
			if(bStarted)
				bStarted = false;
			name = parseKey(jsonmsg,offset,errCode,errDesc);
			if(*errCode != ERR_C_OK)
				return obj;
		}
		else if(c == ':') //Get Value
		{
			*offset+=1;
			JSONValue* val = parseValue(jsonmsg,offset,errCode,errDesc);

			if(*errCode != ERR_C_OK)
				return obj;

			val->name(name);
			obj->insert(val);
		}
		else
		{
			*offset+=1;
			if(c == '}') //End of Object
				break;
		}
	}//while


	if(bStarted)
	{
		*errCode = ERR_C_EXP_OBJARR;
		errDesc->operator = (ERR_C_EXP_OBJARR);
	}

	return obj;
}

JSONArray* JSONFactory::parseJArray(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	JSONArray* jArr = new JSONArray();

	char c = '\0';
	int size = jsonmsg.size();
	bool bStarted = true;
	bool bLookForValue = true;

	c = '\0';
	//check Value
	while(*offset < size)
	{
		c = jsonmsg[*offset];
		if(bStarted && c == '[') //It must start with '['
		{
			bStarted = false;
			bLookForValue = true;
		}
		else if(!bStarted)
		{
			if(bLookForValue)
			{
				//Look for a JValue
				bLookForValue = false;
				JSONValue* val = parseValue(jsonmsg,offset,errCode,errDesc);
				*offset-=1;

				if(*errCode != ERR_C_OK)
					return jArr;

				jArr->insert(val);
			}
			else if(c == ',')
				bLookForValue = true;
			else if(c == ']') //end of array.
			{
				*offset+=1; //Skip ']'
				break;
			}
		}
		*offset+=1;
	}

	if(bStarted)
	{
		*errCode = ERR_C_EXP_ARR;
		errDesc->operator = (ERR_D_EXP_ARR);
	}
	return jArr;
}


string JSONFactory::parseKey(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	string value;
	value = parseString(jsonmsg,offset,errCode,errDesc);
	return value;
}

JSONValue* JSONFactory::parseValue(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	JSONValueType type = T_UNKOWN;

	int size = jsonmsg.size();

	//Read each character.
	while(*offset < size)
	{
		char c = jsonmsg[*offset];

		if(c == 'n') // null value
			type = T_NULL;
		else if(c == 't' || c == 'f') // true or false
			type = T_BOOL;
		else if( ((int)c >= 48 && (int)c <= 57) || c=='-' ) //Start with number or minus.
			type = T_NUMBER;
		else if(c == '\"') // String
			type = T_STRING;
		else if(c == '{') // Object
			type = T_OBJECT;
		else if(c == '[') // Object
			type = T_ARRAY;

		if(type != T_UNKOWN)
			break;

		*offset+=1;
	}

	if(type == T_UNKOWN)
	{
		*errCode = ERR_C_EXP_OBJARR;
		errDesc->operator = (ERR_D_EXP_OBJARR);
	}
	else if(type == T_BOOL)
	{
		JSONBool* jBool = new JSONBool();
		bool val = parseBool(jsonmsg,offset,errCode,errDesc);
		jBool->value(val);
		return jBool;
	}
	else if(type == T_NUMBER)
	{
		JSONNumber* jNum = new JSONNumber();
		bool isInteger = false;
		double val = parseNumber(jsonmsg,&isInteger,offset,errCode,errDesc);
		if(isInteger)
			jNum->value((long)val);
		else
			jNum->value(val);
		return jNum;
	}
	else if(type == T_STRING)
	{
		JSONString* jString = new JSONString();
		string val = parseString(jsonmsg,offset,errCode,errDesc);
		jString->value(val);
		return jString;
	}
	else if(type == T_OBJECT)
	{
		JSONObject* jObj;
		jObj = parseJObject(jsonmsg,offset,errCode,errDesc);
		return jObj;
	}
	else if(type == T_ARRAY)
	{
		JSONArray* jArr;
		jArr = parseJArray(jsonmsg,offset,errCode,errDesc);
		return jArr;
	}


	//The last to check is NULL.
	JSONNull* jNull = new JSONNull();
	if(*errCode == ERR_C_OK) //If there is no previous error.
		parseNull(jsonmsg,offset,errCode,errDesc); // Before return JSONValue, Check if is a valid Null Value.

	return jNull;
}

void JSONFactory::parseNull(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	std::ostringstream out;
	int size = jsonmsg.size();

	//Read each character.
	while(*offset < size)
	{
		char c = jsonmsg[*offset];
		if(c!= ' ' && c!= ',' && c!= '}')
			out << c;
		else
			break;
		*offset+=1;
	}

	string nl = out.str();

	if(strcmp(nl.c_str(),"null") != 0)
	{
		*errCode = ERR_C_EXP_NULL;
		errDesc->operator = (ERR_D_EXP_NULL);
	}
}

bool JSONFactory::parseBool(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	std::ostringstream out;
	int size = jsonmsg.size();

	//Read each character.
	while(*offset < size)
	{
		char c = jsonmsg[*offset];
		if(c!= ' ' && c!= ',' && c!= '}' && c!= '\n')
			out << c;
		else
			break;
		*offset+=1;
	}

	string nl = out.str();

	if(strcmp(nl.c_str(),"true") == 0)
		return true;
	else if(strcmp(nl.c_str(),"false") == 0)
		return false;

	*errCode = ERR_C_EXP_BOOL;
	errDesc->operator = (ERR_D_EXP_BOOL);
	return false;
}

double JSONFactory::parseNumber(string jsonmsg, bool *isInteger, int* offset, int* errCode, string* errDesc)
{

	double val = 0;
	std::ostringstream out;
	int size = jsonmsg.size();

	bool bStarted = true;
	bool bExp = false;

	//Read each character.
	while(*offset < size)
	{
		char c = jsonmsg[*offset];

		if(!bStarted)
			if(c== ' ' || c== ',' || c== '}' || c== '\n') //read Value
				break;

		if(bStarted) //at the begin of number
		{
			if( ( (int)c >= 48 && (int)c <= 57 ) || c=='-') //Digits and sign at the begin are allowed.
				bStarted = false;
			else
			{
				*errCode = ERR_C_EXP_NUMBER;
				errDesc->operator = (ERR_D_EXP_NUMBER);
				return val;
			}

		}
		else	//After the begin.
		{
			if( ( (int)c >= 48 && (int)c <= 57 ) || //Digits
					(!bExp && c=='.') ||			//Dot but not Exponent
					(bExp && (c=='+' || c=='-') ) )	//Exponent an sign
				bExp = false;
			else if(c=='E' || c=='e')				//Exponent
				bExp = true;
			else									//Invalid syntaxes.
			{
				*errCode = ERR_C_EXP_NUMBER;
				errDesc->operator = (ERR_D_EXP_NUMBER);
				return val;
			}
		}//else //After the begin.

		out << c;
		*offset+=1;
	}

	char* pEnd;
	val = strtod(out.str().c_str() ,&pEnd);
	long lVal = (long)val;

	if(val == lVal)
		*isInteger=true;
	else
		*isInteger=false;

	return val;
}

string JSONFactory::parseString(string jsonmsg, int* offset, int* errCode, string* errDesc)
{
	std::ostringstream out;
	bool bStarted = true;
	bool bSlash = false;
	bool bFormatOk = false;
	int size = jsonmsg.size();

	//Read each character.
	while(*offset < size)
	{
		char c = jsonmsg[*offset];

		if(bStarted)
			if(c != '\"') //Check Double Quote
			{
				if(c != ' ') //Skip spaces
				{
					bFormatOk = false;
					break;
				}
			}
			else
				bStarted = false;
		else //bStarted
		{
			if(c == '\\')
				bSlash = true; //turn on Slash Band
			else
			{
				if(!bSlash && c == '\"') //End of String.
				{
					bFormatOk = true;
					//*offset+=1; //Skip '"'
					break;
				}
				if(bSlash)
					bSlash = false; //turn off Slash Band
			}
			out << c;
		}
		*offset+=1;
	}

	if(!bFormatOk)
	{
		*errCode = ERR_C_EXP_DLBQUOTE;
		errDesc->operator =(ERR_D_EXP_DLBQUOTE);
		return "";
	}

	JSONUnicode decode;
	string strDecode = decode.decodeString(out.str());

	return strDecode;
}





