/*
 * JSONValue.cpp
 *
 *  Created on: Aug 13, 2016
 *      Author: Jorge Omar Medra Torres
 *		WebSite: www.jorgemedra.net
 */

#include"JSONLib.h"


JSONValue::JSONValue()
{
	_name = "";
	type = T_UNKOWN;
}
JSONValue::~JSONValue()
{
//	if(type == T_NULL)
//		cout << "DELETED DATA: Key[" << _name << "]:[T_NULL]" << endl;
//	else if(type == T_BOOL)
//		cout << "DELETED DATA: Key[" << _name << "]:[T_BOOL]" << endl;
//	else if(type == T_NUMBER)
//		cout << "DELETED DATA: Key[" << _name << "]:[T_NUMBER]" << endl;
//	else if(type == T_STRING)
//		cout << "DELETED DATA: Key[" << _name << "]:[T_STRING]" << endl;
//	else if(type == T_OBJECT)
//		cout << "DELETED OBJECT: Key[" << _name << "]:[T_OBJECT]" << endl;
//	else if(type == T_ARRAY)
//		cout << "DELETED ARRAY: Key[" << _name << "]:[T_ARRAY]" << endl;
//	else
//		cout << "DELETED UNKOWN: Key[" << _name << "]:[T_UNKOWN]" << endl;
}

void JSONValue::name(string name) {
	_name = name;

}

string JSONValue::name() {
	return _name;
}

string JSONValue::toJSON()
{
	return "";
}

string JSONValue::toJSONValue()
{
	return "";
}

JSONValueType JSONValue::getType()
{
	return type;
}

/**
 * JSONNull
 */

JSONNull::JSONNull()
{
	type = T_NULL;
}
JSONNull::~JSONNull(){}

string JSONNull::toJSON() {
	std::ostringstream out;
	if(strcmp(_name.c_str(),"") != 0)
		out << "\"" << _name << "\":";
	out << toJSONValue();
	return out.str();
}

string JSONNull::toJSONValue()
{
	std::ostringstream out;
	out << "null";
	return out.str();
}

/**
 * JSONNumber
 */
JSONNumber::JSONNumber()
{
	type = T_NUMBER;
	_value = 0;
	isDouble = false;
}
JSONNumber::~JSONNumber(){}

void JSONNumber::value(long val)
{
	isDouble = false;
	_value = (double) val;
}
void JSONNumber::value(double val)
{
	isDouble = true;
	_value = val;
}
long JSONNumber::intValue()
{
	return (long) _value;
}
double JSONNumber::dlbValue()
{
	return _value;
}
bool JSONNumber::isInteger()
{
	return !isDouble;
}

string JSONNumber::toJSON()
{
	//TODO: Create a new Method toJSON to receive the precision value.
	std::ostringstream out;
	if(strcmp(_name.c_str(),"") != 0)
		out << "\"" << _name << "\":";
	out << toJSONValue();
	return out.str();
}

string JSONNumber::toJSONValue()
{
	std::ostringstream out;
	if(!isDouble)
		out << (long)_value;
	else
		out <<  _value;

	return out.str();
}

/**
 * JSONBool
 */

JSONBool::JSONBool()
{
	type = T_BOOL;
	_value = false;
}
JSONBool::~JSONBool(){}

void JSONBool::value(bool val)
{
	_value = val;
}

bool JSONBool::value()
{
	return _value;
}

string JSONBool::toJSON()
{
	std::ostringstream out;
	if(strcmp(_name.c_str(),"") != 0)
		out << "\"" << _name << "\":";
	out << toJSONValue();
	return out.str();
}

string JSONBool::toJSONValue()
{
	std::ostringstream out;
	if(_value)
		out << "true";
	else
		out << "false";

	return out.str();
}
